# Análisis Davis ES11AD2 - Shiny

App Shiny para análisis de escala Davis 0-9 a partir de tablas Scout con conteos por clase.

## Qué hace

- Carga Excel/CSV.
- Permite mapear columnas.
- Filtra `se_name = ES11AD2` y `assessment_type_code = COUNT`.
- Excluye automáticamente registros `ABBOTT` u otros tipos de dato.
- Clasifica escala Davis:
  - `0 = Sin Daño`
  - `1-2 = Low Damage`
  - `3-6 = Medium Damage`
  - `7-9 = High Damage`
- Valida que dentro de cada `trial + momento + tratamiento + repetición`, la suma de `assessment_value` sea igual a `sample_size`.
- Genera análisis overall, por localidad/trial y por grupos de trials definidos por el usuario.
- Mantiene modelo ordinal con `ordinal::clm()` usando `weights = assessment_value`.
- Genera letras de comparación tipo Tukey usando medias estimadas sobre score Davis numérico ponderado.
- Exporta PowerPoint con gráficos y resumen.

## Archivos

```text
app.R
packages.txt
www/
  styles.css
  logo_bayer.jpg
```

## Ejecutar localmente

1. Instalar R y RStudio.
2. Abrir la carpeta del repo en RStudio.
3. Instalar paquetes:

```r
install.packages(readLines("packages.txt"))
```

4. Ejecutar:

```r
shiny::runApp()
```

## Publicar para prueba

Opción simple: shinyapps.io

```r
install.packages("rsconnect")
rsconnect::setAccountInfo(name="TU_USUARIO", token="TU_TOKEN", secret="TU_SECRET")
rsconnect::deployApp()
```

También puede publicarse en Posit Connect o en un servidor propio con Shiny Server.

## Columnas esperadas

La app permite mapear nombres, pero espera roles equivalentes a:

| Rol | Ejemplo |
|---|---|
| Variable evaluada | `se_name` |
| Tipo de assessment | `assessment_type_code` |
| Localidad / ensayo | `trial` o `trial_mod` |
| Momento | `assessment_timing_code` o `timing_mod` |
| Tratamiento | `treatment` o `treatment_mod` |
| Repetición | `replicate_number` |
| Tamaño de muestra | `sample_size` |
| Clase Davis | `assessment_class` |
| Conteo por clase | `assessment_value` |

